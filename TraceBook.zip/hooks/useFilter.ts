import { useState, useMemo, useCallback } from 'react';
import { Place } from '../types';
import { calculateAverageGrade, GRADES } from '../utils/rating';

interface UseFilterReturn {
  selectedGrades: string[];
  isFilterOpen: boolean;
  isFilterClosing: boolean;
  filteredPlaces: Place[];
  toggleGradeFilter: (grade: string) => void;
  selectAllGrades: () => void;
  clearAllGrades: () => void;
  handleFilterToggle: () => void;
  closeFilter: () => void;
}

export function useFilter(places: Place[]): UseFilterReturn {
  const [selectedGrades, setSelectedGrades] = useState<string[]>(GRADES);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isFilterClosing, setIsFilterClosing] = useState(false);

  const filteredPlaces = useMemo(() => {
    return places.filter(p => {
      const avgGrade = calculateAverageGrade(p.visits);
      return selectedGrades.includes(avgGrade);
    });
  }, [places, selectedGrades]);

  const toggleGradeFilter = useCallback((grade: string) => {
    setSelectedGrades(prev =>
      prev.includes(grade)
        ? prev.filter(g => g !== grade)
        : [...prev, grade]
    );
  }, []);

  const selectAllGrades = useCallback(() => {
    setSelectedGrades(GRADES);
  }, []);

  const clearAllGrades = useCallback(() => {
    setSelectedGrades([]);
  }, []);

  const closeFilter = useCallback(() => {
    // Guard: Don't do anything if filter is already closed (prevents flicker)
    if (!isFilterOpen) return;
    setIsFilterClosing(true);
    setTimeout(() => {
      setIsFilterOpen(false);
      setIsFilterClosing(false);
    }, 200);
  }, [isFilterOpen]);

  const handleFilterToggle = useCallback(() => {
    if (isFilterOpen) {
      closeFilter();
    } else {
      setIsFilterOpen(true);
    }
  }, [isFilterOpen, closeFilter]);

  return {
    selectedGrades,
    isFilterOpen,
    isFilterClosing,
    filteredPlaces,
    toggleGradeFilter,
    selectAllGrades,
    clearAllGrades,
    handleFilterToggle,
    closeFilter
  };
}
